import csv
import json

input_file = "dell_machines.csv"
output_file = "../files/dell_machines.json"

main_ip_base = "10.0.127."
drac_ip_base = "10.0.42."
main_ip_counter = 101
drac_ip_counter = 101

servers = []
with open(input_file, 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        servers.append({
            "hostname": row["ServiceTag"],
            "main_ip": f"{main_ip_base}{main_ip_counter}",
            "drac_ip": f"{drac_ip_base}{drac_ip_counter}"
        })
        main_ip_counter += 1
        drac_ip_counter += 1

with open(output_file, 'w') as jsonfile:
    json.dump(servers, jsonfile, indent=4)
